		var taskList = [];
		var $ = function (id) { return document.getElementById(id); }
		
		window.onload = function () {
		
		}